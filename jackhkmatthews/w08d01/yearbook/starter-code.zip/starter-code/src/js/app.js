angular
  .module('wdiYearbook', [
    'ui.router'
  ]);
